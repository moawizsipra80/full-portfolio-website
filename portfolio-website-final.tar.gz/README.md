# Muhammad Moawiz Sipra - Portfolio Website

[![Live Demo](https://img.shields.io/badge/Live%20Demo-View%20Site-red?style=for-the-badge)](https://iaptfqaudtaus.ok.kimi.link)
[![GitHub](https://img.shields.io/badge/GitHub-moawizsipra80-black?style=for-the-badge&logo=github)](https://github.com/moawizsipra80)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/)
[![Instagram](https://img.shields.io/badge/Instagram-Follow-pink?style=for-the-badge&logo=instagram)](https://www.instagram.com/odmonline_120/)

## 🚀 About Me

I'm **Muhammad Moawiz Sipra**, a passionate:
- **MERN Stack Developer** (Formerly at Giant Eyetech)
- **Data Scientist** (PUCIT)
- **SaaS Product Maker**
- **Content Creator** (Collaborated with Shark Tank Pakistan Judges)

## 🌐 Live Website

**[View My Portfolio](https://iaptfqaudtaus.ok.kimi.link)**

## 📱 Connect With Me

| Platform | Link |
|----------|------|
| 🐙 GitHub | [github.com/moawizsipra80](https://github.com/moawizsipra80) |
| 💼 LinkedIn | [Muhammad Moawiz Sipra](https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/) |
| 📸 Instagram | [@odmonline_120](https://www.instagram.com/odmonline_120/) |
| 🎯 Upwork | [Hire Me](https://www.upwork.com/freelancers/~01ddc77465b2abfe0e) |
| 🌐 Website | [odmonline.com](https://odmonline.com) |
| 📊 Kaggle | [@mmoawizsipra](https://www.kaggle.com/mmoawizsipra) |

## 🎬 Featured Collaborations

### Shark Tank Pakistan
- **[Faisal Aftab](https://www.instagram.com/reel/DDR5k2nCtil/)** - Investor
- **[Faisal Warraich](https://www.instagram.com/reel/DDj_J4MgBE3/)** - Shark
- **[Shark Tank Judge](https://www.instagram.com/reel/DD197uvAHR9/)** - Judge

## 🛠️ Tech Stack

- **Frontend:** React, TypeScript, Tailwind CSS, Vite
- **Backend:** Node.js, Express, Django
- **AI/ML:** Python, OpenAI, TensorFlow, LangChain
- **Database:** MongoDB, PostgreSQL

## 🚀 Projects

### AI Projects
- 🤖 AI Customer Assistance Chatbot
- 📄 RAG-Powered PDF Chatbot
- 🛒 AI E-Commerce Support Chatbot
- 🏥 AI Healthcare Prediction Web App

### Full Stack Projects
- 🛍️ Django E-Commerce Website
- 📋 Professional Quotation Software (SaaS)

## 📧 Contact

**Email:** [mmoawizsipra@gmail.com](mailto:mmoawizsipra@gmail.com)

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

---

<p align="center">
  Made with ❤️ by Muhammad Moawiz Sipra
</p>
