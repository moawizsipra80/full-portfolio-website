import { useEffect, useRef, useState } from 'react'
import { Download, Github, Users, Calendar, Building2, Clapperboard, Rocket } from 'lucide-react'

const About = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [counters, setCounters] = useState({ repos: 0, followers: 0, experience: 0 })

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          // Animate counters
          animateCounters()
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const animateCounters = () => {
    const duration = 1500
    const steps = 60
    const interval = duration / steps

    let step = 0
    const timer = setInterval(() => {
      step++
      const progress = step / steps
      const easeOut = 1 - Math.pow(1 - progress, 3)

      setCounters({
        repos: Math.floor(92 * easeOut),
        followers: Math.floor(152 * easeOut),
        experience: Math.floor(3 * easeOut),
      })

      if (step >= steps) {
        clearInterval(timer)
        setCounters({ repos: 92, followers: 152, experience: 3 })
      }
    }, interval)
  }

  const stats = [
    { icon: Github, value: counters.repos, suffix: '+', label: 'GitHub Repositories' },
    { icon: Users, value: counters.followers, suffix: '+', label: 'Instagram Followers' },
    { icon: Calendar, value: counters.experience, suffix: '+', label: 'Years Experience' },
  ]

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
      <div className="absolute top-40 right-0 w-64 h-64 bg-red-500/5 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image Column */}
          <div
            className={`relative transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            <div className="relative">
              {/* Main Image */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="/hero-profile.png"
                  alt="About Muhammad Moawiz Sipra"
                  className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
                />
                {/* Overlay Gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              </div>

              {/* Orbital Decorations */}
              <div className="absolute -top-4 -right-4 w-20 h-20 border-2 border-red-500/30 rounded-full animate-orbit" />
              <div
                className="absolute -bottom-6 -left-6 w-16 h-16 bg-red-500/20 rounded-full blur-xl"
                style={{ animationDuration: '4s' }}
              />
              <div
                className="absolute top-1/2 -right-8 w-4 h-4 bg-red-500 rounded-full animate-pulse"
                style={{ animationDelay: '0.5s' }}
              />

              {/* Floating Card - Work Experience */}
              <div
                className={`absolute -bottom-6 -right-6 bg-dark-700 border border-gray-800 rounded-xl p-4 shadow-xl transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '600ms' }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-red-500" />
                  </div>
                  <div>
                    <p className="text-white font-medium">Giant Eyetech</p>
                    <p className="text-gray-400 text-sm">MERN Stack Developer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Column */}
          <div>
            {/* Section Label */}
            <div
              className={`transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
              }`}
            >
              <span className="text-red-500 font-medium tracking-wider uppercase text-sm">
                About Me
              </span>
            </div>

            {/* Headline */}
            <h2
              className={`mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '100ms' }}
            >
              SaaS Product Maker &{' '}
              <span className="text-gradient">Content Creator</span>
            </h2>

            {/* Description */}
            <div className="mt-6 space-y-4">
              <p
                className={`text-gray-400 leading-relaxed transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '200ms' }}
              >
                I'm Muhammad Moawiz Sipra, a passionate MERN Stack Developer and Data Scientist based in
                Pakistan. Currently pursuing Data Science at Punjab University (PUCIT), I combine
                technical expertise with creative vision to build solutions that matter.
              </p>
              
              {/* Work Experience */}
              <div
                className={`p-4 bg-dark-700/50 border border-gray-800 rounded-xl transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '250ms' }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <Building2 className="w-5 h-5 text-red-500" />
                  <span className="text-white font-semibold">Work Experience</span>
                </div>
                <p className="text-gray-400 text-sm">
                  <span className="text-white">MERN Stack Web App Developer</span> at{' '}
                  <span className="text-red-400">Giant Eyetech</span> - Worked as a bug solver and 
                  full-stack developer, building and maintaining web applications using MongoDB, Express, 
                  React, and Node.js.
                </p>
              </div>

              {/* SaaS Products */}
              <div
                className={`p-4 bg-dark-700/50 border border-gray-800 rounded-xl transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '300ms' }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <Rocket className="w-5 h-5 text-red-500" />
                  <span className="text-white font-semibold">SaaS Product Maker</span>
                </div>
                <p className="text-gray-400 text-sm">
                  I build and release small software products like{' '}
                  <span className="text-white">Professional Quotation Generator</span> with multiple 
                  versions. Each version is continuously improved and updated with new features.
                </p>
              </div>

              {/* Content Creator */}
              <div
                className={`p-4 bg-dark-700/50 border border-gray-800 rounded-xl transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '350ms' }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <Clapperboard className="w-5 h-5 text-red-500" />
                  <span className="text-white font-semibold">Content Creator</span>
                </div>
                <p className="text-gray-400 text-sm">
                  As a content creator, I've had the privilege to collaborate with prominent figures 
                  from <span className="text-red-400">Shark Tank Pakistan</span>. Check out my collaborations 
                  section below to see my work with industry leaders.
                </p>
              </div>

              <p
                className={`text-gray-400 leading-relaxed transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '400ms' }}
              >
                As the CEO of{' '}
                <a
                  href="https://odmonline.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-red-500 hover:underline"
                >
                  ODM Online
                </a>
                , a digital marketing agency, I lead a team dedicated to transforming businesses
                through innovative digital strategies.
              </p>
            </div>

            {/* Stats */}
            <div
              className={`mt-8 grid grid-cols-3 gap-4 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '500ms' }}
            >
              {stats.map((stat, index) => (
                <div
                  key={stat.label}
                  className="text-center p-4 bg-dark-700/50 rounded-xl border border-gray-800 hover:border-red-500/50 transition-all duration-300 group"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <stat.icon className="w-6 h-6 text-red-500 mx-auto mb-2 group-hover:scale-110 transition-transform duration-300" />
                  <p className="text-2xl sm:text-3xl font-bold text-white">
                    {stat.value}
                    {stat.suffix}
                  </p>
                  <p className="text-xs sm:text-sm text-gray-400 mt-1">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <div
              className={`mt-8 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '600ms' }}
            >
              <a
                href="#"
                className="inline-flex items-center gap-2 px-6 py-3 bg-red-500 text-white font-medium rounded-full hover:bg-red-600 hover:shadow-glow transition-all duration-300 transform hover:scale-105"
              >
                <Download size={18} />
                Download CV
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
