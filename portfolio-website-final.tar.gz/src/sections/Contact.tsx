import { useEffect, useRef, useState } from 'react'
import { Mail, MapPin, Globe, Github, Instagram, Linkedin, Send, ExternalLink, Briefcase } from 'lucide-react'

const Contact = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState('')

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setSubmitMessage('Thank you for your message! I will get back to you soon.')
    setFormData({ name: '', email: '', subject: '', message: '' })
    setIsSubmitting(false)

    setTimeout(() => setSubmitMessage(''), 5000)
  }

  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'mmoawizsipra@gmail.com',
      href: 'mailto:mmoawizsipra@gmail.com',
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'Pakistan',
      href: '#',
    },
    {
      icon: Globe,
      label: 'Website',
      value: 'odmonline.com',
      href: 'https://odmonline.com',
    },
  ]

  const socialLinks = [
    {
      icon: Github,
      label: 'GitHub',
      value: 'github.com/moawizsipra80',
      href: 'https://github.com/moawizsipra80',
    },
    {
      icon: Instagram,
      label: 'Instagram',
      value: '@odmonline_120',
      href: 'https://www.instagram.com/odmonline_120/',
    },
    {
      icon: Linkedin,
      label: 'LinkedIn',
      value: 'Muhammad Moawiz Sipra',
      href: 'https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/',
    },
    {
      icon: Briefcase,
      label: 'Upwork',
      value: 'Hire me on Upwork',
      href: 'https://www.upwork.com/freelancers/~01ddc77465b2abfe0e',
    },
  ]

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-red-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`text-red-500 font-medium tracking-wider uppercase text-sm transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Get In Touch
          </span>
          <h2
            className={`mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            Let's Work <span className="text-gradient">Together</span>
          </h2>
          <p
            className={`mt-4 text-gray-400 max-w-2xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            Have a project in mind? Let's create something amazing together. I'm always open to
            discussing new opportunities, creative ideas, or potential collaborations.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Left Column - Contact Info */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
            style={{ transitionDelay: '300ms' }}
          >
            {/* Contact Details */}
            <div className="space-y-6">
              {contactInfo.map((item, index) => (
                <a
                  key={item.label}
                  href={item.href}
                  target={item.href.startsWith('http') ? '_blank' : undefined}
                  rel={item.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="flex items-center gap-4 p-4 bg-dark-700/50 border border-gray-800 rounded-xl hover:border-red-500/50 transition-all duration-300 group"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center group-hover:bg-red-500 transition-colors duration-300">
                    <item.icon className="w-5 h-5 text-red-500 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">{item.label}</p>
                    <p className="text-white font-medium group-hover:text-red-500 transition-colors duration-300">
                      {item.value}
                    </p>
                  </div>
                </a>
              ))}
            </div>

            {/* Social Links */}
            <div className="mt-8">
              <h3 className="text-white font-semibold mb-4">Connect With Me</h3>
              <div className="space-y-4">
                {socialLinks.map((item, index) => (
                  <a
                    key={item.label}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-dark-700/50 border border-gray-800 rounded-xl hover:border-red-500/50 transition-all duration-300 group"
                    style={{ animationDelay: `${(index + 3) * 100}ms` }}
                  >
                    <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center group-hover:bg-red-500 transition-colors duration-300">
                      <item.icon className="w-5 h-5 text-red-500 group-hover:text-white transition-colors duration-300" />
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-400 text-sm">{item.label}</p>
                      <p className="text-white font-medium group-hover:text-red-500 transition-colors duration-300">
                        {item.value}
                      </p>
                    </div>
                    <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-red-500 transition-colors duration-300" />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Contact Form */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
            style={{ transitionDelay: '400ms' }}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name & Email Row */}
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="relative">
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-dark-700/50 border border-gray-800 rounded-lg text-white placeholder-transparent focus:border-red-500 focus:outline-none transition-colors duration-300 peer"
                    placeholder="Name"
                    id="name"
                  />
                  <label
                    htmlFor="name"
                    className="absolute left-4 top-3 text-gray-400 text-sm transition-all duration-300 peer-focus:-top-2.5 peer-focus:left-3 peer-focus:text-xs peer-focus:bg-black peer-focus:px-1 peer-focus:text-red-500 peer-not-placeholder-shown:-top-2.5 peer-not-placeholder-shown:left-3 peer-not-placeholder-shown:text-xs peer-not-placeholder-shown:bg-black peer-not-placeholder-shown:px-1"
                  >
                    Your Name
                  </label>
                </div>
                <div className="relative">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-dark-700/50 border border-gray-800 rounded-lg text-white placeholder-transparent focus:border-red-500 focus:outline-none transition-colors duration-300 peer"
                    placeholder="Email"
                    id="email"
                  />
                  <label
                    htmlFor="email"
                    className="absolute left-4 top-3 text-gray-400 text-sm transition-all duration-300 peer-focus:-top-2.5 peer-focus:left-3 peer-focus:text-xs peer-focus:bg-black peer-focus:px-1 peer-focus:text-red-500 peer-not-placeholder-shown:-top-2.5 peer-not-placeholder-shown:left-3 peer-not-placeholder-shown:text-xs peer-not-placeholder-shown:bg-black peer-not-placeholder-shown:px-1"
                  >
                    Your Email
                  </label>
                </div>
              </div>

              {/* Subject */}
              <div className="relative">
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-dark-700/50 border border-gray-800 rounded-lg text-white placeholder-transparent focus:border-red-500 focus:outline-none transition-colors duration-300 peer"
                  placeholder="Subject"
                  id="subject"
                />
                <label
                  htmlFor="subject"
                  className="absolute left-4 top-3 text-gray-400 text-sm transition-all duration-300 peer-focus:-top-2.5 peer-focus:left-3 peer-focus:text-xs peer-focus:bg-black peer-focus:px-1 peer-focus:text-red-500 peer-not-placeholder-shown:-top-2.5 peer-not-placeholder-shown:left-3 peer-not-placeholder-shown:text-xs peer-not-placeholder-shown:bg-black peer-not-placeholder-shown:px-1"
                >
                  Subject
                </label>
              </div>

              {/* Message */}
              <div className="relative">
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 bg-dark-700/50 border border-gray-800 rounded-lg text-white placeholder-transparent focus:border-red-500 focus:outline-none transition-colors duration-300 resize-none peer"
                  placeholder="Message"
                  id="message"
                />
                <label
                  htmlFor="message"
                  className="absolute left-4 top-3 text-gray-400 text-sm transition-all duration-300 peer-focus:-top-2.5 peer-focus:left-3 peer-focus:text-xs peer-focus:bg-black peer-focus:px-1 peer-focus:text-red-500 peer-not-placeholder-shown:-top-2.5 peer-not-placeholder-shown:left-3 peer-not-placeholder-shown:text-xs peer-not-placeholder-shown:bg-black peer-not-placeholder-shown:px-1"
                >
                  Your Message
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 px-8 py-4 bg-red-500 text-white font-medium rounded-lg hover:bg-red-600 hover:shadow-glow transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-[1.02]"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send size={18} />
                    <span>Send Message</span>
                  </>
                )}
              </button>

              {/* Success Message */}
              {submitMessage && (
                <div className="p-4 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400 text-center animate-fade-in-up">
                  {submitMessage}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
