import { useEffect, useRef, useState } from 'react'
import { Instagram, Play, ExternalLink, Star, TrendingUp, Users } from 'lucide-react'

const ContentCreator = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const collaborations = [
    {
      name: 'Faisal Aftab',
      role: 'Investor - Shark Tank Pakistan',
      description: 'Collaborated with Faisal Aftab, a renowned investor from Shark Tank Pakistan, creating engaging content around entrepreneurship and investment strategies.',
      reelUrl: 'https://www.instagram.com/reel/DDR5k2nCtil/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==',
      image: '/collab-faisal-aftab.jpg',
      stats: '100K+ Views',
    },
    {
      name: 'Faisal Warraich',
      role: 'Shark - Shark Tank Pakistan',
      description: 'Created content with Faisal Warraich, one of the prominent sharks from Shark Tank Pakistan, discussing business growth and innovation.',
      reelUrl: 'https://www.instagram.com/reel/DDj_J4MgBE3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==',
      image: '/collab-faisal-warraich.jpg',
      stats: '150K+ Views',
    },
    {
      name: 'Shark Tank Judge',
      role: 'Judge - Shark Tank Pakistan',
      description: 'Collaborated with another distinguished judge from Shark Tank Pakistan, sharing insights on startup ecosystem and investment opportunities.',
      reelUrl: 'https://www.instagram.com/reel/DD197uvAHR9/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==',
      image: '/collab-shark-judge.jpg',
      stats: '80K+ Views',
    },
  ]

  const metrics = [
    { icon: Users, value: '10K+', label: 'Total Followers' },
    { icon: Play, value: '500K+', label: 'Total Views' },
    { icon: TrendingUp, value: '50+', label: 'Brand Collabs' },
    { icon: Star, value: '3', label: 'Shark Tank Collabs' },
  ]

  return (
    <section
      id="content-creator"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-red-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`text-red-500 font-medium tracking-wider uppercase text-sm transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Content Creator
          </span>
          <h2
            className={`mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            Shark Tank <span className="text-gradient">Collaborations</span>
          </h2>
          <p
            className={`mt-4 text-gray-400 max-w-2xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            Proud to have collaborated with some of the most influential figures from Shark Tank Pakistan, 
            creating content that inspires and educates aspiring entrepreneurs.
          </p>
        </div>

        {/* Metrics */}
        <div
          className={`grid grid-cols-2 md:grid-cols-4 gap-6 mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '300ms' }}
        >
          {metrics.map((metric, index) => (
            <div
              key={metric.label}
              className="text-center p-6 bg-dark-700/50 rounded-xl border border-gray-800 hover:border-red-500/50 transition-all duration-300 group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <metric.icon className="w-8 h-8 text-red-500 mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
              <p className="text-2xl sm:text-3xl font-bold text-white">{metric.value}</p>
              <p className="text-sm text-gray-400 mt-1">{metric.label}</p>
            </div>
          ))}
        </div>

        {/* Collaborations Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {collaborations.map((collab, index) => (
            <div
              key={collab.name}
              className={`group relative bg-dark-700/50 border border-gray-800 rounded-2xl overflow-hidden hover:border-red-500/50 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{ transitionDelay: `${400 + index * 150}ms` }}
            >
              {/* Header */}
              <div className="p-6">
                {/* Role Badge */}
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-500/20 text-red-400 text-xs font-medium rounded-full mb-4">
                  <Star className="w-3 h-3" />
                  {collab.role}
                </div>

                {/* Name */}
                <h3 className="text-xl font-display font-bold text-white group-hover:text-red-500 transition-colors duration-300 mb-2">
                  {collab.name}
                </h3>

                {/* Description */}
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {collab.description}
                </p>

                {/* Stats */}
                <div className="flex items-center gap-2 text-red-400 text-sm mb-4">
                  <Play className="w-4 h-4" />
                  <span>{collab.stats}</span>
                </div>

                {/* Watch Reel Button */}
                <a
                  href={collab.reelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-medium rounded-full hover:shadow-lg transition-all duration-300 group/btn"
                >
                  <Instagram className="w-4 h-4" />
                  <span>Watch Reel</span>
                  <ExternalLink className="w-3 h-3 transform group-hover/btn:translate-x-1 transition-transform duration-300" />
                </a>
              </div>

              {/* Hover Glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-red-500/0 via-red-500/10 to-red-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            </div>
          ))}
        </div>

        {/* Instagram CTA */}
        <div
          className={`mt-12 text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '800ms' }}
        >
          <a
            href="https://www.instagram.com/odmonline_120/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-3 border border-gray-700 text-white font-medium rounded-full hover:border-red-500 hover:bg-red-500/10 transition-all duration-300 group"
          >
            <Instagram size={20} />
            <span>Follow Me on Instagram</span>
            <ExternalLink
              size={18}
              className="transform group-hover:translate-x-1 transition-transform duration-300"
            />
          </a>
        </div>
      </div>
    </section>
  )
}

export default ContentCreator
