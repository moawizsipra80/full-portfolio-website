import { Github, Instagram, Linkedin, Heart } from 'lucide-react'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const socialLinks = [
    {
      icon: Github,
      href: 'https://github.com/moawizsipra80',
      label: 'GitHub',
    },
    {
      icon: Instagram,
      href: 'https://www.instagram.com/odmonline_120/',
      label: 'Instagram',
    },
    {
      icon: Linkedin,
      href: 'https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/',
      label: 'LinkedIn',
    },
  ]

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <footer className="relative py-12 overflow-hidden">
      {/* Top Border */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />

      {/* Background Glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-32 bg-red-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center">
          {/* Logo */}
          <button
            onClick={scrollToTop}
            className="group relative mb-6"
            aria-label="Scroll to top"
          >
            <span className="font-display text-3xl font-bold text-white group-hover:text-red-500 transition-colors duration-300">
              Sipra
            </span>
            <span className="absolute -bottom-1 left-1/2 w-0 h-0.5 bg-red-500 group-hover:w-full group-hover:left-0 transition-all duration-300"></span>
          </button>

          {/* Tagline */}
          <p className="text-gray-400 text-center mb-6 max-w-md">
            Web Developer | Data Scientist | Content Creator
          </p>

          {/* Social Links */}
          <div className="flex gap-4 mb-8">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 border border-gray-800 rounded-full text-gray-400 hover:border-red-500 hover:text-red-500 hover:shadow-glow-sm transition-all duration-300 transform hover:scale-110"
                aria-label={link.label}
              >
                <link.icon size={18} />
              </a>
            ))}
          </div>

          {/* Divider */}
          <div className="w-full max-w-xs h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent mb-6" />

          {/* Copyright */}
          <p className="text-gray-500 text-sm text-center">
            © {currentYear} Muhammad Moawiz Sipra. All rights reserved.
          </p>

          {/* Credit */}
          <p className="mt-2 text-gray-600 text-sm flex items-center gap-1">
            Designed with <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" /> in
            Pakistan
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
