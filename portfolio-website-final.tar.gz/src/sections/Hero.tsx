import { useEffect, useRef, useState } from 'react'
import { ArrowDown, Github, Instagram, Linkedin, Briefcase, ChevronRight } from 'lucide-react'

const Hero = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  // Particle animation
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animationId: number
    let particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      radius: number
    }> = []

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    const createParticles = () => {
      particles = []
      const particleCount = Math.min(80, Math.floor((canvas.width * canvas.height) / 15000))
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          radius: Math.random() * 2 + 1,
        })
      }
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle, i) => {
        particle.x += particle.vx
        particle.y += particle.vy

        if (particle.x < 0) particle.x = canvas.width
        if (particle.x > canvas.width) particle.x = 0
        if (particle.y < 0) particle.y = canvas.height
        if (particle.y > canvas.height) particle.y = 0

        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(255, 255, 255, 0.5)'
        ctx.fill()

        particles.slice(i + 1).forEach((other) => {
          const dx = particle.x - other.x
          const dy = particle.y - other.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 100) {
            ctx.beginPath()
            ctx.moveTo(particle.x, particle.y)
            ctx.lineTo(other.x, other.y)
            ctx.strokeStyle = `rgba(255, 0, 0, ${0.15 * (1 - distance / 100)})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        })
      })

      animationId = requestAnimationFrame(animate)
    }

    resize()
    createParticles()
    animate()

    window.addEventListener('resize', () => {
      resize()
      createParticles()
    })

    setTimeout(() => setIsLoaded(true), 100)

    return () => {
      cancelAnimationFrame(animationId)
    }
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  const quickLinks = [
    { name: 'Projects', href: '#projects', icon: ChevronRight },
    { name: 'Social Links', href: '#social-links', icon: ChevronRight },
    { name: 'Contact', href: '#contact', icon: ChevronRight },
  ]

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Particle Canvas */}
      <canvas ref={canvasRef} className="particle-canvas" />

      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-dark-800 to-black opacity-80" />
      
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-red-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-red-600/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-500/5 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="order-2 lg:order-1 text-center lg:text-left">
            {/* Badge */}
            <div
              className={`inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/30 rounded-full mb-6 transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '200ms' }}
            >
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-red-400 text-sm font-medium">Available for Freelance Work</span>
            </div>

            {/* Greeting */}
            <div
              className={`transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '300ms' }}
            >
              <span className="font-accent text-2xl sm:text-3xl text-red-500">Hello, I'm</span>
            </div>

            {/* Name */}
            <h1 className="mt-2 space-y-1">
              <span
                className={`block font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white transition-all duration-700 ${
                  isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '500ms' }}
              >
                MUHAMMAD
              </span>
              <span
                className={`block font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-gradient transition-all duration-700 ${
                  isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '700ms' }}
              >
                MOAWIZ SIPRA
              </span>
            </h1>

            {/* Subtitle */}
            <div
              className={`mt-6 transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '900ms' }}
            >
              <p className="text-lg sm:text-xl text-gray-300 font-light tracking-wide">
                MERN Stack Developer <span className="text-red-500">|</span> Data Scientist{' '}
                <span className="text-red-500">|</span> SaaS Product Maker
              </p>
              <div className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-orange-500/20 border border-pink-500/30 rounded-full">
                <Instagram className="w-4 h-4 text-pink-500" />
                <span className="text-pink-400 text-sm font-medium">Content Creator & Shark Tank Collaborator</span>
              </div>
            </div>

            {/* Description */}
            <p
              className={`mt-6 text-base sm:text-lg text-gray-400 max-w-xl mx-auto lg:mx-0 transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '1100ms' }}
            >
              Transforming ideas into digital reality. I craft innovative SaaS products, build AI-powered 
              solutions, and create content that inspires. Former MERN Stack Developer at Giant Eyetech.
            </p>

            {/* Quick Links */}
            <div
              className={`mt-6 flex flex-wrap gap-3 justify-center lg:justify-start transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '1200ms' }}
            >
              {quickLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="inline-flex items-center gap-1 px-4 py-2 bg-dark-700/50 border border-gray-700 rounded-full text-sm text-gray-300 hover:border-red-500 hover:text-white transition-all duration-300"
                >
                  {link.name}
                  <link.icon className="w-3 h-3" />
                </button>
              ))}
            </div>

            {/* CTA Buttons */}
            <div
              className={`mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '1300ms' }}
            >
              <button
                onClick={() => scrollToSection('#projects')}
                className="px-8 py-3 bg-red-500 text-white font-medium rounded-full hover:bg-red-600 hover:shadow-glow transition-all duration-300 transform hover:scale-105"
              >
                View My Work
              </button>
              <button
                onClick={() => scrollToSection('#contact')}
                className="px-8 py-3 border border-gray-600 text-white font-medium rounded-full hover:border-red-500 hover:text-red-500 transition-all duration-300 transform hover:scale-105"
              >
                Get In Touch
              </button>
            </div>

            {/* Social Links */}
            <div
              className={`mt-8 flex gap-4 justify-center lg:justify-start transition-all duration-700 ${
                isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: '1500ms' }}
            >
              <a
                href="https://github.com/moawizsipra80"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 border border-gray-700 rounded-full text-gray-400 hover:border-red-500 hover:text-red-500 hover:shadow-glow-sm transition-all duration-300 transform hover:scale-110"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
              <a
                href="https://www.instagram.com/odmonline_120/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 border border-gray-700 rounded-full text-gray-400 hover:border-pink-500 hover:text-pink-500 hover:shadow-glow-sm transition-all duration-300 transform hover:scale-110"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 border border-gray-700 rounded-full text-gray-400 hover:border-blue-500 hover:text-blue-500 hover:shadow-glow-sm transition-all duration-300 transform hover:scale-110"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="https://www.upwork.com/freelancers/~01ddc77465b2abfe0e"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 border border-gray-700 rounded-full text-gray-400 hover:border-green-500 hover:text-green-500 hover:shadow-glow-sm transition-all duration-300 transform hover:scale-110"
                aria-label="Upwork"
              >
                <Briefcase size={20} />
              </a>
            </div>
          </div>

          {/* Right Content - Profile Image */}
          <div
            className={`order-1 lg:order-2 flex justify-center transition-all duration-1000 ${
              isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
            }`}
            style={{ transitionDelay: '400ms' }}
          >
            <div className="relative">
              {/* Glow Effect */}
              <div className="absolute inset-0 bg-red-500/20 rounded-3xl blur-3xl scale-110 animate-pulse" />
              
              {/* Image Container */}
              <div className="relative w-72 h-96 sm:w-80 sm:h-[28rem] lg:w-96 lg:h-[32rem] animate-float">
                <div className="absolute inset-0 bg-gradient-to-b from-red-500/20 to-transparent rounded-3xl" />
                <img
                  src="/hero-profile.png"
                  alt="Muhammad Moawiz Sipra"
                  className="w-full h-full object-cover rounded-3xl drop-shadow-2xl border border-gray-800"
                />
              </div>

              {/* Floating Stats Card */}
              <div
                className={`absolute -bottom-4 -left-4 bg-dark-700/90 backdrop-blur-sm border border-gray-800 rounded-xl p-4 shadow-xl transition-all duration-700 ${
                  isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '1600ms' }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
                    <span className="text-red-500 font-bold">92+</span>
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">GitHub Repos</p>
                    <p className="text-gray-400 text-xs">Open Source</p>
                  </div>
                </div>
              </div>

              {/* Floating Badge */}
              <div
                className={`absolute -top-4 -right-4 bg-dark-700/90 backdrop-blur-sm border border-gray-800 rounded-xl p-3 shadow-xl transition-all duration-700 ${
                  isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '1700ms' }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                    <Instagram className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-white text-xs font-medium">Content Creator</p>
                  </div>
                </div>
              </div>

              {/* Orbital Decorations */}
              <div className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full animate-orbit" />
              <div
                className="absolute bottom-10 left-0 w-3 h-3 bg-red-400 rounded-full animate-orbit"
                style={{ animationDuration: '20s', animationDirection: 'reverse' }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={() => scrollToSection('#about')}
        className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center text-gray-500 hover:text-red-500 transition-all duration-500 ${
          isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
        style={{ transitionDelay: '2000ms' }}
        aria-label="Scroll to about section"
      >
        <span className="text-sm mb-2">Scroll Down</span>
        <ArrowDown size={20} className="animate-bounce-slow" />
      </button>
    </section>
  )
}

export default Hero
