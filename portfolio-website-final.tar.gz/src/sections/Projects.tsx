import { useEffect, useRef, useState } from 'react'
import { ExternalLink, Github, ArrowRight, Cpu, ShoppingCart, FileText, MessageSquare, Activity, Download } from 'lucide-react'

const Projects = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const projects = [
    {
      title: 'AI Customer Assistance Chatbot',
      description:
        'An intelligent AI-powered chatbot designed to provide seamless customer support. Features natural language processing, context awareness, and automated responses for enhanced user experience.',
      image: '/project-ai-chatbot.jpg',
      tags: ['Python', 'OpenAI', 'NLP', 'AI/ML'],
      github: 'https://github.com/moawizsipra80',
      demo: '#',
      featured: true,
      icon: MessageSquare,
    },
    {
      title: 'RAG-Powered PDF Chatbot',
      description:
        'A sophisticated document analysis tool using Retrieval-Augmented Generation (RAG) technology. Upload PDFs and chat with your documents using OpenAI and Python for intelligent information extraction.',
      image: '/project-rag-pdf.jpg',
      tags: ['Python', 'OpenAI', 'RAG', 'LangChain'],
      github: 'https://github.com/moawizsipra80',
      demo: '#',
      featured: true,
      icon: FileText,
    },
    {
      title: 'AI E-Commerce Support Chatbot',
      description:
        'AI-Powered Customer Support Chatbot specifically designed for e-commerce stores. Handles order inquiries, product recommendations, and customer service automation with machine learning.',
      image: '/project-ecommerce-chatbot.jpg',
      tags: ['Python', 'TensorFlow', 'NLP', 'E-commerce'],
      github: 'https://github.com/moawizsipra80',
      demo: '#',
      featured: false,
      icon: ShoppingCart,
    },
    {
      title: 'AI Healthcare Prediction Web App',
      description:
        'Full-stack AI-Integrated Healthcare Prediction Web Application. Uses machine learning algorithms to predict health outcomes, analyze symptoms, and provide personalized health insights.',
      image: '/project-healthcare.jpg',
      tags: ['React', 'Python', 'ML', 'Full Stack'],
      github: 'https://github.com/moawizsipra80',
      demo: '#',
      featured: false,
      icon: Activity,
    },
    {
      title: 'Django E-Commerce Website',
      description:
        'Fully functional online store built with Django. Features include user authentication, product catalog, shopping cart, payment integration, order management, and admin dashboard.',
      image: '/project-django-ecommerce.jpg',
      tags: ['Django', 'Python', 'PostgreSQL', 'Full Stack'],
      github: 'https://github.com/moawizsipra80',
      demo: '#',
      featured: false,
      icon: ShoppingCart,
    },
    {
      title: 'Professional Quotation Software',
      description:
        'A comprehensive SaaS quotation management system. Features include customizable templates, client management, PDF generation, automated calculations, and version control for releases.',
      image: '/project-quotation.jpg',
      tags: ['HTML', 'CSS', 'JavaScript', 'SaaS'],
      github: 'https://github.com/moawizsipra80/Professiona-Quotation-software-download-link',
      demo: '#',
      featured: false,
      icon: FileText,
      isSaaS: true,
      versions: [
        { name: 'v1.0', url: '#' },
        { name: 'v2.0', url: '#' },
      ],
    },
  ]

  return (
    <section
      id="projects"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-red-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`text-red-500 font-medium tracking-wider uppercase text-sm transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Portfolio
          </span>
          <h2
            className={`mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            Featured <span className="text-gradient">Projects</span>
          </h2>
          <p
            className={`mt-4 text-gray-400 max-w-2xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            A showcase of my AI-powered solutions, SaaS products, and full-stack web applications. 
            Demo videos available on my LinkedIn profile.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className={`group relative bg-dark-700/50 border border-gray-800 rounded-2xl overflow-hidden hover:border-red-500/50 transition-all duration-500 ${
                isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
              } ${project.featured ? 'md:col-span-2 lg:col-span-1' : ''}`}
              style={{ transitionDelay: `${300 + index * 100}ms` }}
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300" />

                {/* SaaS Badge */}
                {project.isSaaS && (
                  <div className="absolute top-4 left-4 px-3 py-1 bg-green-500 text-white text-xs font-medium rounded-full flex items-center gap-1">
                    <Cpu className="w-3 h-3" />
                    SaaS Product
                  </div>
                )}

                {/* Featured Badge */}
                {project.featured && !project.isSaaS && (
                  <div className="absolute top-4 left-4 px-3 py-1 bg-red-500 text-white text-xs font-medium rounded-full">
                    Featured
                  </div>
                )}

                {/* Icon */}
                <div className="absolute bottom-4 right-4 w-12 h-12 bg-red-500/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                  <project.icon className="w-6 h-6 text-red-500" />
                </div>

                {/* Hover Actions */}
                <div className="absolute inset-0 flex items-center justify-center gap-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-white/10 backdrop-blur-sm rounded-full text-white hover:bg-red-500 transition-colors duration-300 transform hover:scale-110"
                    aria-label="View GitHub"
                  >
                    <Github size={20} />
                  </a>
                  <a
                    href={project.demo}
                    className="p-3 bg-white/10 backdrop-blur-sm rounded-full text-white hover:bg-red-500 transition-colors duration-300 transform hover:scale-110"
                    aria-label="View Demo"
                  >
                    <ExternalLink size={20} />
                  </a>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs font-medium text-gray-400 bg-dark-600 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Title */}
                <h3 className="text-lg font-display font-bold text-white group-hover:text-red-500 transition-colors duration-300 mb-2">
                  {project.title}
                </h3>

                {/* Description */}
                <p className="text-gray-400 text-sm leading-relaxed mb-4">{project.description}</p>

                {/* Version Links for SaaS */}
                {project.isSaaS && project.versions && (
                  <div className="mb-4">
                    <p className="text-xs text-gray-500 mb-2">Download Versions:</p>
                    <div className="flex gap-2">
                      {project.versions.map((version) => (
                        <a
                          key={version.name}
                          href={version.url}
                          className="inline-flex items-center gap-1 px-3 py-1 bg-red-500/20 text-red-400 text-xs font-medium rounded-full hover:bg-red-500 hover:text-white transition-all duration-300"
                        >
                          <Download className="w-3 h-3" />
                          {version.name}
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Link */}
                <a
                  href={project.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-red-500 hover:text-red-400 font-medium text-sm transition-colors duration-300 group/link"
                >
                  <span>View Project</span>
                  <ArrowRight
                    size={16}
                    className="transform group-hover/link:translate-x-1 transition-transform duration-300"
                  />
                </a>
              </div>

              {/* Hover Border Glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-red-500/0 via-red-500/20 to-red-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            </div>
          ))}
        </div>

        {/* Demo Videos CTA */}
        <div
          className={`mt-8 text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '900ms' }}
        >
          <a
            href="https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-3 border border-gray-700 text-white font-medium rounded-full hover:border-red-500 hover:bg-red-500/10 transition-all duration-300 group"
          >
            <ExternalLink size={20} />
            <span>Watch Demo Videos on LinkedIn</span>
            <ArrowRight
              size={18}
              className="transform group-hover:translate-x-1 transition-transform duration-300"
            />
          </a>
        </div>

        {/* View All CTA */}
        <div
          className={`mt-6 text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '1000ms' }}
        >
          <a
            href="https://github.com/moawizsipra80"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-3 border border-gray-700 text-white font-medium rounded-full hover:border-red-500 hover:bg-red-500/10 transition-all duration-300 group"
          >
            <Github size={20} />
            <span>View All Projects on GitHub</span>
            <ArrowRight
              size={18}
              className="transform group-hover:translate-x-1 transition-transform duration-300"
            />
          </a>
        </div>
      </div>
    </section>
  )
}

export default Projects
