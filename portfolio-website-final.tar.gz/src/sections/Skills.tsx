import { useEffect, useRef, useState } from 'react'
import {
  Code2,
  Palette,
  Database,
  Globe,
  BarChart3,
  PenTool,
  Layers,
  Megaphone,
} from 'lucide-react'

const Skills = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const skills = [
    { name: 'HTML/CSS', proficiency: 95, icon: Code2, color: 'from-orange-500 to-red-500' },
    { name: 'JavaScript', proficiency: 90, icon: Globe, color: 'from-yellow-400 to-yellow-600' },
    { name: 'Python', proficiency: 85, icon: Database, color: 'from-blue-500 to-blue-700' },
    { name: 'Django', proficiency: 80, icon: Layers, color: 'from-green-500 to-green-700' },
    { name: 'C++', proficiency: 75, icon: Code2, color: 'from-purple-500 to-purple-700' },
    { name: 'Data Analysis', proficiency: 85, icon: BarChart3, color: 'from-cyan-500 to-blue-600' },
    { name: 'Web Design', proficiency: 90, icon: Palette, color: 'from-pink-500 to-rose-500' },
    { name: 'Digital Marketing', proficiency: 88, icon: Megaphone, color: 'from-indigo-500 to-purple-600' },
    { name: 'Content Creation', proficiency: 92, icon: PenTool, color: 'from-red-500 to-red-700' },
  ]

  return (
    <section
      id="skills"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-dark-800/50 to-black" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`text-red-500 font-medium tracking-wider uppercase text-sm transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            My Expertise
          </span>
          <h2
            className={`mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            Skills <span className="text-gradient">& Technologies</span>
          </h2>
          <p
            className={`mt-4 text-gray-400 max-w-2xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            A comprehensive toolkit of technologies and skills I've mastered throughout my journey
            in web development, data science, and digital marketing.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, index) => (
            <div
              key={skill.name}
              className={`group relative bg-dark-700/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-red-500/50 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{
                transitionDelay: `${300 + index * 100}ms`,
                transform: isVisible ? 'rotateY(0)' : 'rotateY(-90deg)',
              }}
            >
              {/* Card Content */}
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div
                  className={`w-12 h-12 rounded-lg bg-gradient-to-br ${skill.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}
                >
                  <skill.icon className="w-6 h-6 text-white" />
                </div>

                {/* Skill Info */}
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-white font-semibold group-hover:text-red-500 transition-colors duration-300">
                      {skill.name}
                    </h3>
                    <span className="text-red-500 font-bold">{skill.proficiency}%</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out group-hover:animate-shimmer`}
                      style={{
                        width: isVisible ? `${skill.proficiency}%` : '0%',
                        transitionDelay: `${500 + index * 100}ms`,
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Hover Glow */}
              <div className="absolute inset-0 rounded-xl bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          className={`mt-12 text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '1200ms' }}
        >
          <p className="text-gray-400 mb-4">
            Always learning and exploring new technologies to stay ahead.
          </p>
          <a
            href="https://github.com/moawizsipra80"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-red-500 hover:text-red-400 font-medium transition-colors duration-300"
          >
            <span>View My GitHub</span>
            <svg
              className="w-4 h-4 transform group-hover:translate-x-1 transition-transform"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}

export default Skills
