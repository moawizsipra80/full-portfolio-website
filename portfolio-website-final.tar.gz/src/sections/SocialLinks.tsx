import { useEffect, useRef, useState } from 'react'
import { 
  Github, 
  Instagram, 
  Linkedin, 
  Briefcase, 
  Globe, 
  ExternalLink,
  MessageCircle
} from 'lucide-react'

const SocialLinks = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const socialLinks = [
    {
      name: 'GitHub',
      username: '@moawizsipra80',
      description: 'Check out my code repositories and open-source contributions',
      icon: Github,
      url: 'https://github.com/moawizsipra80',
      color: 'from-gray-700 to-gray-900',
      followers: '92+ Repos',
    },
    {
      name: 'LinkedIn',
      username: 'Muhammad Moawiz Sipra',
      description: 'Professional network and career updates',
      icon: Linkedin,
      url: 'https://www.linkedin.com/in/muhammad-moawiz-sipra-a12342222/',
      color: 'from-blue-600 to-blue-800',
      followers: 'Connect',
    },
    {
      name: 'Instagram',
      username: '@odmonline_120',
      description: 'Content creation and Shark Tank collaborations',
      icon: Instagram,
      url: 'https://www.instagram.com/odmonline_120/',
      color: 'from-purple-600 via-pink-600 to-orange-500',
      followers: '152+ Followers',
    },
    {
      name: 'Upwork',
      username: 'Hire Me',
      description: 'Freelance services and project portfolio',
      icon: Briefcase,
      url: 'https://www.upwork.com/freelancers/~01ddc77465b2abfe0e',
      color: 'from-green-600 to-green-800',
      followers: 'Available',
    },
    {
      name: 'Website',
      username: 'odmonline.com',
      description: 'My digital marketing agency',
      icon: Globe,
      url: 'https://odmonline.com',
      color: 'from-red-600 to-red-800',
      followers: 'Visit',
    },
    {
      name: 'Kaggle',
      username: '@mmoawizsipra',
      description: 'Data science notebooks and competitions',
      icon: MessageCircle,
      url: 'https://www.kaggle.com/mmoawizsipra',
      color: 'from-cyan-600 to-blue-700',
      followers: 'Follow',
    },
  ]

  const featuredReels = [
    {
      title: 'Collaboration with Faisal Aftab',
      subtitle: 'Investor - Shark Tank Pakistan',
      url: 'https://www.instagram.com/reel/DDR5k2nCtil/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==',
    },
    {
      title: 'Collaboration with Faisal Warraich',
      subtitle: 'Shark - Shark Tank Pakistan',
      url: 'https://www.instagram.com/reel/DDj_J4MgBE3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==',
    },
    {
      title: 'Collaboration with Shark Tank Judge',
      subtitle: 'Judge - Shark Tank Pakistan',
      url: 'https://www.instagram.com/reel/DD197uvAHR9/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==',
    },
  ]

  return (
    <section
      id="social-links"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`text-red-500 font-medium tracking-wider uppercase text-sm transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Connect With Me
          </span>
          <h2
            className={`mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            My <span className="text-gradient">Social Links</span>
          </h2>
          <p
            className={`mt-4 text-gray-400 max-w-2xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            Connect with me across all platforms. Follow my journey as a developer, content creator, and entrepreneur.
          </p>
        </div>

        {/* Social Links Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {socialLinks.map((link, index) => (
            <a
              key={link.name}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`group relative bg-dark-700/50 border border-gray-800 rounded-2xl p-6 hover:border-red-500/50 transition-all duration-500 overflow-hidden ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{ transitionDelay: `${300 + index * 100}ms` }}
            >
              {/* Gradient Background on Hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${link.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
              
              {/* Icon */}
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${link.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <link.icon className="w-7 h-7 text-white" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-display font-bold text-white group-hover:text-red-500 transition-colors duration-300 mb-1">
                {link.name}
              </h3>
              <p className="text-red-400 text-sm font-medium mb-2">{link.username}</p>
              <p className="text-gray-400 text-sm mb-4">{link.description}</p>

              {/* Footer */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 bg-dark-600 px-3 py-1 rounded-full">
                  {link.followers}
                </span>
                <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-red-500 transform group-hover:translate-x-1 transition-all duration-300" />
              </div>
            </a>
          ))}
        </div>

        {/* Featured Instagram Reels */}
        <div
          className={`transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '900ms' }}
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-display font-bold text-white mb-2">
              Featured <span className="text-gradient">Collaborations</span>
            </h3>
            <p className="text-gray-400">Watch my collaborations with Shark Tank Pakistan judges</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {featuredReels.map((reel, index) => (
              <a
                key={reel.title}
                href={reel.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative bg-gradient-to-br from-purple-600/20 via-pink-600/20 to-orange-500/20 border border-gray-800 rounded-xl p-6 hover:border-pink-500/50 transition-all duration-300"
                style={{ transitionDelay: `${1000 + index * 100}ms` }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <Instagram className="w-6 h-6 text-pink-500" />
                  <span className="text-pink-400 text-sm font-medium">Instagram Reel</span>
                </div>
                <h4 className="text-white font-semibold mb-1 group-hover:text-pink-400 transition-colors duration-300">
                  {reel.title}
                </h4>
                <p className="text-gray-400 text-sm mb-4">{reel.subtitle}</p>
                <div className="flex items-center gap-2 text-pink-400 text-sm font-medium">
                  <ExternalLink className="w-4 h-4" />
                  <span>Watch Now</span>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div
          className={`mt-12 text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '1200ms' }}
        >
          <p className="text-gray-400 mb-4">Let's collaborate and create something amazing together!</p>
          <a
            href="mailto:mmoawizsipra@gmail.com"
            className="inline-flex items-center gap-2 px-8 py-3 bg-red-500 text-white font-medium rounded-full hover:bg-red-600 hover:shadow-glow transition-all duration-300 transform hover:scale-105"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Get In Touch</span>
          </a>
        </div>
      </div>
    </section>
  )
}

export default SocialLinks
